package test_Vehicle;

public interface Vehicle {
	abstract void start();
	abstract void stop();
}

class Car implements Vehicle{
	Car audi;
	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("��С����");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("С������վ");
	}
	
}

class Bike implements Vehicle{
	Bike yongjiu;
	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("�����г�");
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("�������г�");
	}
	
}