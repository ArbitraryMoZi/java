package test02;

class Experience{
	private String educationBackground;
	private String skills;
	
	public void setExperience(String educationBackground, String skills) 
	{
		this.educationBackground=educationBackground;
		this.skills=skills;
	}
public String toString() 
{
	return educationBackground + skills;
}
}

/*�����࣬ʵ��Clone����*
*/
class Resume implements Cloneable{
	private String name; //����
	private String sex; //�Ա�
	private int age; //����
	private Experience experience;//��������
	
	public Resume(String name,String sex,int age) {
		this.name=name;
		this.sex=sex;
		this.age=age;
		this.experience=new Experience();
	}
	public void setAge(int age) {
		this.age=age;
	}
	public int getAge() {
		return age;
	}
	public Experience getExperience() {
		return experience;
	}
	public void setExperience(String educationBackground, String skills) {
		experience=new Experience();
		experience.setExperience(educationBackground, skills);
	}
	public void displayResume() {
		System.out.println("������"+name+" �Ա�"+sex+" ���䣺"+age);
		System.out.println("����������"+experience.toString());
	}
	public Object clone() {
		try {
			return (Resume)super.clone();
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resume zhangsan=new Resume("zhangsan","��",24);
		zhangsan.setExperience("2009-2013�Ͷ��ڼ���ش�ѧ","��ͨjava,c,c++�ȴ���");
		zhangsan.displayResume();
	
	Resume zhangsan2=(Resume)zhangsan.clone();
	zhangsan2.setExperience("2012-2013�Ͷ��ڼ���ش�ѧ","��ͨ����");
	zhangsan2.displayResume();
	zhangsan.displayResume();
	//zhangsan2.displayResume();
   }
}
