package test01;

public class ArrayStack<E> implements Stack<E>{
	
	private Array<E> array;
	
	public ArrayStack (int capacity) {
		array = new Array<>(capacity);
	}

	public ArrayStack () {
		array = new Array<>();
	}
	
	public int getSize() {
		return array.getSize();
	}
	
	public boolean isEmpty() {
		return array.isEmpty();
	}
	
	public int getCapacity() {
		return array.getCapacity();
	}
	
	public void push(E e) {
		array.addLast(e);
	}
	
	public E pop1() {
		return array.removeLast();
	}
	
	public E peek1() {
		return array.getLast();
	}
	
	public String toSting() {
		StringBuilder res = new StringBuilder();
		res.append("Stack: ");
		res.append('[');
		for(int i= 0; i<array.getSize(); i++) {
			res.append(array.get(i));
			if(i!=array.getSize()-1)
				res.append(",");
		}
		res.append("] top");
		return res.toString();
	}

	public E pop() {
		// TODO Auto-generated method stub
		return array.removeLast();
	}

	public E peek() {
		// TODO Auto-generated method stub
		return array.getLast();
	}
	
}



