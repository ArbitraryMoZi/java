public static boolean getLogin(String name, String password)
			throws SQLException {
		ResultSet rs = findForResultSet("select * from tb_userlist where name='"
				+ name + "' and pass='" + password + "'");//执行SQL查询
		return rs.next();
	}
