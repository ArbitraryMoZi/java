package com.wyr.exer;
import java.lang.reflect.Array;
import java.util.Arrays;

@SuppressWarnings("unused")
public class test004 {
	public static void main(String[] args) {
/*888888888888888888888888�ȽϺ����ĵ���88888888888888888888888888888888888*/
	/*String���µıȽϷ���*/
	String s11 = new String ("hello");
	String s12 = new String ("hi");
	System.out.println(s11.compareTo(s12));//��String���µ�compareTo�ķ����йأ�ע��÷����ķ���
	        
	/*һά����ıȽϷ���*/
	int a11[] = {1,2,3,4};
    int a12[] = {1,2,3,4};
	System.out.println(a11.equals(a12));//�Ƚϵ�ַ
	System.out.println(a11==a12);//�Ƚϵ�ַ
	System.out.println(Arrays.equals(a11,a12));//�Ƚ�ֵ
	        
    /*��ά����ıȽϷ���*/
	int arr1[][] = { {1,2,3}, {4,5}, {6,7,8,9} };
	int arr2[][] = { {1,2,3}, {4,5}, {6,7,8,9} };
	System.out.println(Arrays.deepEquals(arr1, arr2));//�Ƚ�ֵ
	System.out.println();
	        
	        
/*888888888888888888888888888888888888888888888888888888888888888888888888*/
	byte b11[] = {8,94,75,25,124,3,2};
	Arrays.sort(b11);
    System.out.print(Arrays.toString(b11));
	System.out.println();
	for(byte number: b11)
	{
	  System.out.print(number + " ");
	}System.out.println();
/*8888888888888888��������88888888888888888888888888888888888888888888888888888888*/
	int[] array1 = {1,2,3,4,5,6,7};
    int[] array2 = new int [7];
	        
	for(int i=0;i<array1.length;i++)
	{
	   array2[i] = array1[i];
	}System.out.println();
    for(int i=0;i<array2.length;i++)
    {
	   System.out.print(array2[i] + " ");
	}System.out.println();
	System.out.println();
/*8888888888888888���ָ�������88888888888888888888888888888888888888888888888888888888*/
	int[] array11 = {1,2,3,4,5,6,7};
    int[] array21 = new int [25];
	        
	System.arraycopy(array11,1,array21,0,array11.length-1);
	for(int i=0;i<array21.length;i++)
	{
	   System.out.print(array21[i] + " ");
	}System.out.println();
	System.out.println();

/*8888888888888888��������������88888888888888888888888888888888888888888888888888888888*/
    int[][] a = new int[][]{{1,2,3}, {4}, {5,6,7,8}};
	for(int i=0;i<a.length;i++)
	{ for(int j=0;j<a[i].length;j++)
	  { System.out.print(a[i][j] + "   ");
	  }System.out.println();
    }
  }       
}
