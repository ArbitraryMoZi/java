package com.wyr.exer;

import java.io.*;
import java.util.*;

@SuppressWarnings("unused")
public class test016 
	{ 
	    public static void main(String args[]) throws Exception 
	    { 
	        @SuppressWarnings("resource")
			Scanner cin=new Scanner(System.in); 
	        int a=cin.nextInt(),b=cin.nextInt(); 
	        System.out.println(a+b); 
	    }
	}

