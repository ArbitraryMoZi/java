package com.wyr.exer;

//static�ؼ������ȴ�ӡ   �̳�
public class test006 {
	public static void main(String[] args)  {
		new Meal();
	}
}

class Meal {
	
	public Meal() {
		System.out.println("meal");
	}
	
	Bread bread = new Bread();
}

class Bread {
	static{
		System.out.println("Bread is loaded");
	}
	public Bread() {
		System.out.println("bread");
	}
}