package com.wyr.exer;

class fu
{
	public void name()
	{
	    System.out.println("name baba");
	}
	public static void age()
	{
	    System.out.println("age 22");
	}
	public fu(int a)
	{
	    System.out.println("hobby huahua"+a);
	}
	public void birthday ()
	{
		System.out.println("122��111");
	}
	public fu()
	{
	    System.out.println("QQQQQQQ");
	}
}


class zi extends fu
{
	public void name()
	{
	    System.out.println("name erzi");
	}
	public static void age()
	{
	    System.out.println("age 11");
	}
	public zi(int a)
	{
	    System.out.println("hobby chi"+a);
	}
	public void birth (int i)
	{
		System.out.println("12��11"+i);
	}   
	
}

public class test011 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		@SuppressWarnings("unused")
		int a=100;
		//super.fu(a);
        fu f = new zi(i);
        f.name();
        fu.age();
        f.birthday();
        zi z = (zi) f;
        z.birth(i);                                         
	}

}