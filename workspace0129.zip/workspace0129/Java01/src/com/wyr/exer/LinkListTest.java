package com.wyr.exer;

import java.util.*;

public class LinkListTest {

	public static void main(String[] args) {
		LinkedList link = new LinkedList();
		
		link.removeFirst();
		link.removeLast();
		
		
		
	}

}
