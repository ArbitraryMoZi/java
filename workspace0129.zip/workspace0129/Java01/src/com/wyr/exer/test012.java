package com.wyr.exer;

abstract class fu1
{
    public abstract void name();

    public static void age()
    {
        System.out.println("age 22");
    }
    public  fu1() {}

    public abstract void birthday ();

}


class erzi extends fu1
{
    public void name()
    {
        System.out.println("�ҵ�����");
    }
    public static void age()
    {
        System.out.println("age 11");
    }
    public erzi(){}

    public void birthday()
    {
        System.out.println("������11.11");
    }

}
abstract class sun extends fu1
{
    public sun ()
    {
        System.out.println("hobby wan");
    }

    public void birthday ()
    {
        System.out.println("12yue12ri ");
    }
}

public class test012
{
    public static void main(String[] args)
    {
        fu1 f = new erzi();
        f.birthday();
        f.name();
        fu1.age();
    }
}