package com.wyr.exer;

class test
{
					
	private String nameA="A";
					
	public test() 
	{
	   System.out.println("hahaha");
	}
	public test(int weight)
	{
		System.out.println("popopo");
	}
					
	public void getName() 
	{
		System.out.println("����"+nameA);
	}
}
public class test010 extends test
{
   public test010(int age) 
   {
	   System.out.println("yayaya");
   }
   private String nameB="B"; 
					
   public void getName() 
   {
		System.out.println("����"+nameB);
		//super.getName();
	}
	public static void main(String[] args) 
	{
		test010 b=new test010(12);
		b.getName();
	}
}
