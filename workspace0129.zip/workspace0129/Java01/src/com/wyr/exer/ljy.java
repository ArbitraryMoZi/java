package com.wyr.exer;

public class ljy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
