package com.wyr.exer;

import java.util.ArrayList;
import java.util.Scanner;

public class HellowWorld {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("hellow");
    	@SuppressWarnings("unused")
		ArrayList<Integer> list = new ArrayList<>();
		
		String string = String.valueOf(100);
		System.out.println(string);
		int a = Integer.valueOf("1000");
		System.out.println(a);
		Scanner scan = new Scanner(System.in);
		int a1 = scan.nextInt();
		System.out.println(a1);

		
	}
}
