package com.wyr.exer;

public class test013 {

	public static void main(String[] args) {
		//Integer Int = new Integer(10);
		// ���鷳�ľ�����
		// public static String toBinaryString(int i)
		System.out.println(java.lang.Integer.toBinaryString(100));
		// public static String toOctalString(int i)
		System.out.println(java.lang.Integer.toOctalString(100));
		// public static String toHexString(int i)
		System.out.println(java.lang.Integer.toHexString(100));

		// public static final int MAX_VALUE
		System.out.println(java.lang.Integer.MAX_VALUE);
		// public static final int MIN_VALUE
		System.out.println(java.lang.Integer.MIN_VALUE);
	}
}


