package com.wyr.exer;

class Shape11 {
	public String name = "shape";
	
	public Shape11(){
		System.out.println("shape constructor");
	}
	
	public void printType11() {
		// TODO Auto-generated method stub
		
	}

	public void printType1() {
		// TODO Auto-generated method stub
		
	}

	public void printType() {
		System.out.println("this is shape");
	}
	
	public void printName1() {
		System.out.println("shape");
	}

	public void printName() {
		// TODO Auto-generated method stub
		
	}
}

class Circle00 extends Shape11 {
	public String name = "circle";
	
	public Circle00() {
		System.out.println("circle constructor");
	}
	
	public void printType11() {
		System.out.println("this is circle");
	}
	
	public void printName1() {
		System.out.println("circle");
	}
}

//˼��ͬ�����������
public class test008 {
	public static void main(String[] args)  {
		Shape11 shape = new Circle00();
		System.out.println(shape.name);
		shape.printName1();
		shape.printName1();
	}

}

