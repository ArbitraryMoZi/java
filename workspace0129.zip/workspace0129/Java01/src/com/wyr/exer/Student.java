package com.wyr.exer;

public class Student {
	
	int age ;
	String name;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = new Student( 6,"wyr" ) ;
		System.out.println(student);	
	}
	
public Student (int age, String name)
{
	this.age = age ;
	this.name = name ;
}

public String toString() 
{ 
	return "student [age=" + age + ", name = " + name + "]" ; }
}
