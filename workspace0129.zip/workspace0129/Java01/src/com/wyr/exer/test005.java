package com.wyr.exer;

//���ؼ���static��super   �̳�
	class Shape {
		
		protected String name;
		
		//public Shape(){
		//	name = "shape";
		//}
		
		public Shape(String name) {
			this.name = name;
		}
	}

	class Circle extends Shape {
		
		@SuppressWarnings("unused")
		private double radius;
		
		public Circle() {
			super("circle");
			radius = 0;
		}
		
		public Circle(double radius) {
			super("circle");
			this.radius = radius;
		}
		
		public Circle(double radius,String name) {
			super(name);
			this.radius = radius;
			this.name = name;
		}
	}


	public class test005 {
		public static void main(String[] args)  {
			new Circle();
		}
	}
