package com.wyr.exer;

class Bread12 {
	static{
		System.out.println("Bread is loaded");
	}
	public void Bread() {
		System.out.println("bread");
	}
}

//static�ؼ������ȴ�ӡ��������ͬ���Ĵ�ӡ   �̳�
public class test007 {
	public static void main(String[] args) throws ClassNotFoundException {
		
		@SuppressWarnings("unused")
		Bread12 bread = new Bread12();
		@SuppressWarnings("unused")
		Bread12 bread1 = new Bread12();
	}
}
