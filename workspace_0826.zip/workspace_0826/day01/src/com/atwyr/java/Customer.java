package com.atwyr.java;

public class Customer {
	private String firstName;
	private String lastName;
	private Accout1 accout1;
	
	public Customer() {	
	}
	
	public Customer(String f,String i) {
		firstName = f;
		lastName = i;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Accout1 getAccout1() {
		return accout1;
	}

	public void setAccout(Accout1 accout1) {
		this.accout1 = accout1;
	}
	
	

}
