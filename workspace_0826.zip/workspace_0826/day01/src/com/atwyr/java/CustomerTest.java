package com.atwyr.java;

public class CustomerTest {
	public static void main(String[] args) {
		
	
	Customer c = new Customer("Jane","Smith");
	Accout1 a = new Accout1(1000,2000.10,1.23);
	
	c.setAccout(a);
	c.getAccout1().deposit(100);
	c.getAccout1().withdraw(960);
	c.getAccout1().withdraw(2000);
	System.out.println(c.getFirstName() + c.getLastName() + c.getAccout1().getId());
	
	}
}