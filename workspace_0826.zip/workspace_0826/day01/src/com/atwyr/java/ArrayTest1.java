package com.atwyr.java;

public class ArrayTest1 {
	public static void main(String[] args) {

		// 1.一维数组的声明和初始化
		int[] ids;
		// 1.1静态初始化
		ids = new int[] { 1, 2, 3, 4 };
		// 1.2动态初始化
		String[] names = new String[3];

		// 2.调用数组指定元素
		ids[3] = 192;
		int a = ids[3];
		System.out.println(a);
		names[0] = "张三喜欢李四";
		String b = names[0];
		System.out.println(b);

		// 3.获取数组长度
		System.out.println(ids.length);
		System.out.println(names.length);

		// 4.遍历数组
		for (int n = 0; n < ids.length; n++) {
			System.out.print(ids[n] + " ");
		}
		System.out.println();
		for (int n = 0; n < names.length; n++) {
			System.out.print(names[n] + " ");
		}
		System.out.println();

		// 5.默认初始化值
		int[] x = new int[3];
		for (int n = 0; n < x.length; n++) {
			System.out.print(x[n] + " ");
		}
		System.out.println();
		float[] y = new float[3];
		for (int n = 0; n < y.length; n++) {
			System.out.print(y[n] + " ");
		}
		System.out.println();
		char[] z = new char[3];
		for (int n = 0; n < z.length; n++) {
			System.out.print("%" + z[n] + "*" + "   ");
		}
		System.out.println();
		boolean[] w = new boolean[3];
		for (int n = 0; n < w.length; n++) {
			System.out.print(w[n] + " ");
		}
		System.out.println();
		String[] t = new String[3];
		for (int n = 0; n < t.length; n++) {
			System.out.print(t[n] + " ");
		}
		System.out.println();
	}
}
