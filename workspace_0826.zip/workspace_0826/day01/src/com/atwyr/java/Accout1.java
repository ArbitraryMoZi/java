package com.atwyr.java;

public class Accout1 {
	// 属性
	private int id;//账号
	private double balance;//余额
	private double annualInterestRate;//年利率

	// 构造器
	public Accout1() {
	}

	public Accout1(int id, double balance, double annualInterestRate) {
		this.id = id;
		this.balance = balance;
		this.annualInterestRate = annualInterestRate;
	}

	// 方法
	public int getId() {
		return id;
	}

	public void setId(int id) {
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public void setAnnualInterestRate(double annualInterestRate) {
	}
	
	public void withdraw(double amount) { //取钱
		if(balance <= amount) {
			System.out.println("用户余额不足");
		}
		else {
			if(amount > 0) {
				balance = balance - amount;
				System.out.println("成功取出" + amount + "元！");
			}
			else {
				System.out.println("取钱金额不能为空！");
			}
		}
	}
	
	public void deposit(double amount) {  //存钱
		if(amount >= 100) {
			balance = balance + amount;
			System.out.println("存钱成功！");
		}
		else {
			System.out.println("存钱金额不能小于100！");
		}
	}
	
	
}
