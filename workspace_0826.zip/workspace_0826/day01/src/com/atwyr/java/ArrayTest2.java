package com.atwyr.java;

/**
 * 
 * @Description
 * @author YanrWang  Email：1497642769@qq.com
 * @version
 * @date  2021年9月28日上午9:37:20
 *
 */
public class ArrayTest2 {

	public static void main(String[] args) {
		// 二维数组的声明和初始化
		int[][] arr1 = new int[4][5];
		int[][] arr2 = new int[][] { { 1, 2, 3 }, { 4, 5 }, { 6, 7, 8 } };

		String[][] arr3 = new String[2][];
		String[][] arr4 = new String[5][4];

		// 调用数组的指定元素
		int a = arr1[1][2];
		System.out.println(a);
		System.out.println(arr2[0][1]);
		arr3[1] = new String[5];
		System.out.println(arr3[1][1]);
		arr4[0][1] = "王妍茹";
		System.out.println(arr4[0][1]);

		// 获取数组长度
		System.out.println(arr1.length);
		System.out.println(arr2[1].length);
		System.out.println(arr3.length);
		System.out.println(arr4[4].length);

		// 遍历数组
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr1[i].length; j++) {
				System.out.print(arr1[i][j] + " ");
			}
			System.out.println();
		}

		for (int i = 0; i < arr2.length; i++) {
			for (int j = 0; j < arr2[i].length; j++) {
				System.out.print(arr2[i][j] + " ");
			}
			System.out.println();
		}

		/* arr3内部未赋值，不可输出 */
		/*
		 * for(int i = 0;i<arr3.length;i++) { for(int j=0;j<arr3[i].length;j++) {
		 * System.out.print(arr3[i][j] + " "); } System.out.println(); }
		 */

		for (int i = 0; i < arr4.length; i++) {
			for (int j = 0; j < arr4[i].length; j++) {
				System.out.print(arr4[i][j] + " ");
			}
			System.out.println();
		}

		// 数组元素的默认初始值
		System.out.println(arr1[0][0]);
		System.out.println(arr4[0][0]);
		char[][] arr5 = new char[4][5];
		System.out.println("*" + arr5[0][0] + "*");
		float[][] arr6 = new float[4][5];
		System.out.println(arr6[0][0]);
		boolean[][] arr7 = new boolean[4][5];
		System.out.println(arr7[0][0]);
	}

}
