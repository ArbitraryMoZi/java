package com.atwyr.exer;

public class Student {

	static int i;// 控制循环变量
	int number;// 学生学号
	int state;// 学生年级
	int score;// 学生成绩

	/**
	 * 
	 * @Description 输出所有w年级学生信息
	 * @author YanrWang
	 * @date 2021年10月15日下午6:58:38
	 * @param stu 要查找的数组
	 * @param w   要查找的年级
	 */
	public void searchState(Student[] stu, int w) {
		for (i = 0; i < 20; i++) {
			if (stu[i].state == w) {
				System.out.println(stu[i].state + "年级的学生学号为：" + stu[i].number + ",  成绩为：" + stu[i].score);
			}
		}
	}

	/**
	 * 
	 * @Description 使用冒泡排序按学生成绩排序(升序)，并输出学生信息
	 * @author YanrWang
	 * @date 2021年10月15日下午6:57:55
	 * @param stu 要查找的数组
	 */
	public void sort(Student[] stu) {
		for (i = 0; i < stu.length - 1; i++) {
			for (int q = 0; q < stu.length - 1 - i; q++) {
				if (stu[q].score > stu[q + 1].score) {
					// !!!!!注意：交换的不是成绩！交换的是student对象！
					Student temp;
					temp = stu[q];
					stu[q] = stu[q + 1];
					stu[q + 1] = temp;
				}
			}
		}
	}

	/**
	 * 
	 * @Description 遍历输出方法
	 * @author YanrWang
	 * @date 2021年10月15日下午7:00:40
	 * @param stu 要查找的数组
	 */
	public void method(Student[] stu) {
		for (i = 0; i < stu.length; i++) {
			System.out.println(stu[i].number + "学号的学生年级为：" + stu[i].state + " 成绩为：" + stu[i].score);
		}
	}

	public static void main(String[] args) {
		Student[] stu = new Student[20];// 20个学生数组对象
		for (i = 0; i < 20; i++) {
			// 给数组元素赋值
			stu[i] = new Student();
			// 学号
			stu[i].number = i + 1;
			// 年级范围在[1,6]
			stu[i].state = (int) (Math.random() * (6 - 1 + 1) + 1);
			// 成绩范围在[10,100]
			stu[i].score = (int) (Math.random() * (100 - 10 + 1) + 10);

		}

		// ？
		//错误示例：stu[i].method(stu);  
		//原因:由于i=20跳出循环，再stu[20]就会数组超界，为了好看，避免出现点后括号里还有stu，可以再定义一个变量
		Student test = new Student();
		test.method(stu);

		System.out.println("**********输出所有3年级学生信息**********");
		test.searchState(stu, 3);

		System.out.println("----------根据成绩对学生信息排序---------");
		test.sort(stu);
		test.method(stu);

	}

}
