package com.atwyr.exer;

import java.util.Scanner;

/**
 * 
 * @Description
 * @author YanrWang  Email：1497642769@qq.com
 * @version
 * @date  2021年9月27日下午8:57:57
 *
 */
public class exer01 {
	public static void main(String[] args) {
		// 使用scanner，读取学生人数
		int i;
		Scanner s = new Scanner(System.in);
		System.out.println("请输入学生人数： ");
		int num = s.nextInt();

		// 创建数组，存储学生成绩，动态初始化
		int[] t = new int[num];

		// 给数组中的元素赋值
		System.out.println("请输入" + num + "个学生成绩：");
		for (i = 0; i < t.length; i++) {
			t[i] = s.nextInt();
		}

		// 获取数组元素中的最大值：最高分
		int max = 0;
		for (i = 0; i < t.length; i++) {
			if (max < t[i])
				max = t[i];
		}

		// 根据每个同学与最高分的差值输出成绩的等级
		for (i = 0; i < num; i++) {
			if (max - t[i] <= 10)
				System.out.println("第" + (i+1) + "个学生成绩为：" + t[i] + ",等级为A");
			else if (max - t[i] <= 20)
				System.out.println("第" + (i+1) + "个学生成绩为：" + t[i] + ",等级为B");
			else if (max - t[i] <= 30)
				System.out.println("第" + (i+1) + "个学生成绩为：" + t[i] + ",等级为C");
			else
				System.out.println("第" + (i+1) + "个学生成绩为：" + t[i] + ",等级为D");
		}
	}
}
