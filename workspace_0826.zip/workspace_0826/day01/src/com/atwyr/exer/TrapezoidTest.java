package com.atwyr.exer;
class Trapezoid {
		double upperBottom = 0;
		double lowerBottom = 0;
		double high = 0;
		double area = 0;
		
	    public double getUpperBottom() {
			return upperBottom;
		}

		public void setUpperBottom(double upperBottom) {
			this.upperBottom = upperBottom;
		}

		public double getLowerBottom() {
			return lowerBottom;
		}

		public void setLowerBottom(double lowerBottom) {
			this.lowerBottom = lowerBottom;
		}

		public double getHigh() {
			return high;
		}

		public void setHigh(double high) {
			this.high = high;
		}

		public double getArea(){
	        area=(upperBottom+lowerBottom)*high/2;
	        return area;
	     }	
    
}

public class TrapezoidTest {
    public static void main(String[] args) {
		/*
		 * double upperBottom = 0; double lowerBottom = 0; double high = 0; double area
		 * = 0;
		 */
	    Trapezoid t = new Trapezoid();
	    
	    t.getArea();
	    
  }
    
}
