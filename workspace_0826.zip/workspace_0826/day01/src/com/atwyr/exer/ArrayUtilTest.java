package com.atwyr.exer;

public class ArrayUtilTest {
	public static void main(String[] args) {
		ArrayUtil test = new ArrayUtil();
		int[] arr = new int[] { 12, 32, 65, 78, 9, -1, 0, -29 };

		
		  int[] arr0 = new int[arr.length]; arr0 = test.copy(arr); test.print(arr0);
		 

		
		  test.print(arr); 
		  int max = test.getMax(arr); System.out.println(max); 
		  int min = test.getMin(arr); System.out.println(min); 
		  int s = test.getSum(arr);
		  System.out.println(s); double a = test.getAvg(arr); System.out.println(a);
		 
		  test.reverse(arr); test.print(arr);
		 
		  int w = test.search(arr, 90); System.out.println(w);
		 
		 test.sort(arr); test.print(arr);
		 int w1 = test.search(arr, 78); System.out.println(w1);
	}

}
