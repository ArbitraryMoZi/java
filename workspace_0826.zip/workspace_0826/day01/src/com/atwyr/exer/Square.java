package com.atwyr.exer;
/**
 * 
 * @Description
 * @author YanrWang  Email：1497642769@qq.com
 * @version
 * @date  2021年10月15日下午5:25:48
 *
 */
public class Square {

	public int m;
	int n;
	double area;

	public void method() {
		int i = 0, j = 0;
		//第一行
		for (i = 0; i < m; i++) {
			System.out.print("*");
		}
		System.out.println();
		//中间n-2行
		for (j = 0; j < n - 2; j++) {
			for (i = 0; i <= m - 1; i++) {
				if (i == 0 || i == m - 1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		//最后一行
		for (i = 0; i < m; i++) {
			System.out.print("*");
		}
		System.out.println();
	    //输出面积
		area = m * n;
		System.out.println("矩形面积为：" + area);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square s = new Square();
		s.m = 20;
		s.n = 18;
		s.method();
	}

}
