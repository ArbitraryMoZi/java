package com.atwyr.exer;

class Circle {
	
	public int r;
	double s;
	
	public double Mianji() {
		 s = Math.PI * r * r;
		return s;
	}

}

public class CircleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c1 = new Circle();
		c1.r=10;
		double p = c1.Mianji();
		System.out.println(p);
	}

}
