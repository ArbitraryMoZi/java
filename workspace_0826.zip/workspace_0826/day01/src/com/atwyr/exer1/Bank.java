package com.atwyr.exer1;

public class Bank {
	private Customer[] customer;//存放多个客户的数组
	private int numberOfCustomer;//记录客户个数
	
	public Bank() {
		customer  = new Customer[10];
	}
	
	public void addCustomer(String f,String l) {//添加客户
		Customer cu = new Customer(f,l);
		customer[numberOfCustomer] = cu;
		numberOfCustomer++;
	}
	
	public int getNumberOfCustomer() {//获取客户个数
		return numberOfCustomer;
	}
	
	public Customer getCustomer(int index) {//获取指定索引位置的客户
		//return customer[index];   可能报异常
		if(index >= 0 && index < numberOfCustomer)
			return customer[index];
		else
			return null;
	}

}
