package com.atwyr.exer1;

public class Accout {
	private double balance;
	
	
	public Accout() {
		
	}
	
	public Accout(double init_balance) {
		balance = init_balance;
	}

	public double getBalance() {
		return balance;
	}
	
	public void deposit(double amt) {
		if(amt >= 100) {
			balance = balance + amt;
			System.out.println("存钱成功！");
		}
		else {
			System.out.println("存钱金额不能小于100！");
		}
	}
	
	public void withdraw(double amt) {
		if(balance <= amt) {
			System.out.println("用户余额不足");
		}
		else {
			if(amt > 0) {
				balance = balance - amt;
				System.out.println("成功取出" + amt + "元！");
			}
			else {
				System.out.println("取钱金额不能为空！");
			}
		}
	}

}
