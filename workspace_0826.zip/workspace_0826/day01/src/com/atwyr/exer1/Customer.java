package com.atwyr.exer1;

public class Customer {
	private String firstName;
	private String lastName;
	private Accout accout;
	
	public Customer(String f, String l) {
		this.firstName = f;
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;	
	}

	public Accout getAccout() {
		return accout;
	}

	public void setAccout(Accout accout) {
		// TODO Auto-generated method stub
			accout = accout;
	}
	
	


}
