package com.atwyr.exer1;

public class BankTest {
	public static void main(String[] args) {
		Bank b = new Bank();
		b.addCustomer("jine", "smith");
	
		
		b.getCustomer(0).setAccout(new Accout(2000));
		b.getCustomer(0).getAccout().withdraw(500);
		
		double balance = b.getCustomer(0).getAccout().getBalance();
		System.out.println(b.getCustomer(0).getFirstName() + b.getCustomer(0).getAccout());
		b.addCustomer("雷", "党");
		System.out.println(b.getNumberOfCustomer());
		
		
	}

}
